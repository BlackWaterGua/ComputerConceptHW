#include <iostream>
using namespace std;
#ifndef REPTILE_H_INCLUDED
#define REPTILE_H_INCLUDED

class reptile{

public:
    void crawl();

};



#endif // REPTILE_H_INCLUDED
