#include "meat.h"


void meat::eat_meat(){
    cout << "eat meat" << endl;
}
