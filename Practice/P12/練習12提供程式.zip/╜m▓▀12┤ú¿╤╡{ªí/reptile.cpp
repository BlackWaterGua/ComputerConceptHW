#include "reptile.h"

void reptile::crawl(){
    cout << "crawl" << endl;
}
