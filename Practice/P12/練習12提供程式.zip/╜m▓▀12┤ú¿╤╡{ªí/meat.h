#include <iostream>
using namespace std;
#ifndef MEAT_H_INCLUDED
#define MEAT_H_INCLUDED

class meat{

public:
    void eat_meat();

};


#endif // MEAT_H_INCLUDED
